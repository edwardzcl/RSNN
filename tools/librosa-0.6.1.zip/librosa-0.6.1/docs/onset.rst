.. _onset:

.. automodule:: librosa.onset
