# Audio Examples

The licenses and the origins of the audio files are as follows:

* http://freemusicarchive.org/music/We_Is_Shore_Dedicated/Smiley/12_Sometimes_With_Friends
* http://freemusicarchive.org/music/Karissa_Hobbs/Age_of_Flowers/09_Lets_Go_Fishin
* http://freemusicarchive.org/music/Kevin_MacLeod/Classical_Sampler/Danse_Macabre_-_Sad_Part
* https://www.jamendo.com/track/1316074/stargazer-from-texas
* http://freemusicarchive.org/music/Cheese_N_Pot-C/The_Raps_Well/16_-_The_Raps_Well_Clean_Album_Version
* `sir_duke_slow.mp3` and `sir_duke_fast.mp3` were recorded by Stefan Balke and are released under CC BY 4.0.
