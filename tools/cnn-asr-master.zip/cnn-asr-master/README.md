a simple asr system using cnn
