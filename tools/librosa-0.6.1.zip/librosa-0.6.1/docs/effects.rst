.. _effects:

.. automodule:: librosa.effects
